# ThreeHingeArch
Describing the first order reaction of a three-hinged arch to a load
